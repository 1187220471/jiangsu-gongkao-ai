export interface AIMessage {
  role: 'system' | 'user' | 'assistant'
  content: string
}

export async function callAI(messages: AIMessage[], temperature = 0.7): Promise<string> {
  const apiKey = process.env.DEEPSEEK_API_KEY || process.env.DASHSCOPE_API_KEY
  const baseUrl = process.env.DEEPSEEK_BASE_URL || process.env.DASHSCOPE_BASE_URL || 'https://api.deepseek.com'

  if (!apiKey) {
    throw new Error('AI API Key not configured')
  }

  const response = await fetch(`${baseUrl}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: process.env.DEEPSEEK_API_KEY ? 'deepseek-chat' : 'qwen-max',
      messages,
      temperature,
      max_tokens: 2500,
    }),
  })

  if (!response.ok) {
    const error = await response.text()
    throw new Error(`AI API error: ${error}`)
  }

  const data = await response.json()
  return data.choices[0].message.content
}

// 各题型可选主题领域，用于丰富出题多样性
const QUESTION_TOPICS: Record<string, string[]> = {
  'social': [
    '政务服务改革（如一件事一次办、数字政府、身份码推广、互联网+政务）',
    '养老服务创新（如时间银行、互助养老、居家养老上门服务、智慧养老）',
    '基层治理模式（如党建引领、社区自治、网格化管理、微心愿墙）',
    '乡村振兴举措（如乡村旅游、直播带货农产品、规划师下乡、特色产业发展）',
    '公共服务优化（如智慧医疗、互联网+教育、青年人才驿站、共享服务）',
    '社会治理创新（如时间银行志愿服务、商户自治、新业态监管）',
    '生态环境保护（如河长制、垃圾分类、绿色低碳、河道治理）',
    '文化建设发展（如沉浸式演艺、非遗保护、文旅融合、书香社会）',
    '民生保障改善（如老旧小区改造、加装电梯、停车难、物业管理）',
    '数字化治理（如大数据应用、智慧城市建设、数字化服务平台）',
    '市场监管创新（如餐饮油烟治理、小摊贩管理、预付卡监管）',
    '交通安全管理（如一盔一带、电动自行车治理、快递外卖交通违法）',
    '教育双减政策落实（如校外培训治理、课后服务、素质教育）',
  ],
  'attitude': [
    '干部队伍建设（如德才兼备以德为先、选人用人、高素质干部）',
    '青年干部成长（如扎根基层、实干担当、青春奋斗）',
    '创新精神与担当（如四敢精神、敢为敢闯敢干敢首创）',
    '为民服务宗旨（如以人民为中心、初心使命、群众路线）',
    '法治政府建设（如依法行政、公正司法、法治思维）',
    '诚信与规则意识（如社会信用体系、契约精神）',
    '奋斗与实干精神（如艰苦奋斗、求真务实、久久为功）',
    '团结合作意识（如团队协作、集体主义）',
    '学习提升观念（如终身学习、本领恐慌）',
    '廉洁自律要求（如清正廉洁、防腐拒变）',
  ],
  'organize': [
    '调研活动组织（如基层调研、民情走访、专项调查）',
    '宣传活动策划（如政策宣讲、文明创建、科普宣传）',
    '培训活动安排（如业务培训、技能培训、干部轮训）',
    '会议座谈组织（如座谈会、听证会、议事会）',
    '志愿服务活动（如社区服务、帮扶慰问、文明劝导）',
    '比赛评比活动（如知识竞赛、技能大赛、评优评先）',
    '专项整治行动（如安全检查、环境治理、市场整顿）',
    '试点推广工作（如新模式试点、经验总结、全面推广）',
    '节日活动策划（如节庆活动、文化展演、民俗活动）',
    '应急演练组织（如消防演练、防汛演练、防疫演练）',
  ],
  'emergency': [
    '突发安全事故（如火灾、交通事故、建筑坍塌）',
    '群体性事件（如聚集维权、网络舆情、群体性投诉）',
    '自然灾害应对（如台风、暴雨、地震、暴雪）',
    '公共卫生事件（如食品安全、传染病、职业病）',
    '公共设施故障（如停水停电、电梯困人、燃气泄漏）',
    '执法冲突处理（如暴力抗法、阻碍执法、投诉纠纷）',
    '矛盾纠纷调解（如邻里纠纷、劳资纠纷、医患纠纷）',
    '紧急任务执行（如临时接待、突击检查、紧急会议）',
  ],
  'relationship': [
    '与领导的关系（如工作汇报、任务分配、意见分歧）',
    '与同事的关系（如工作配合、竞争合作、矛盾化解）',
    '与下属的关系（如任务布置、激励管理、能力培养）',
    '与群众的关系（如群众投诉、政策解释、诉求回应）',
    '与服务对象的关系（如企业服务、办事群众、管理对象）',
    '跨部门协调（如部门合作、信息共享、资源调配）',
    '新人适应问题（如角色转换、能力短板、融入团队）',
  ],
  'self': [
    '个人优势与不足（如性格特点、能力特长、短板弱项）',
    '报考动机与职业规划（如为什么选择公务员、职业目标）',
    '工作经历与感悟（如最难忘的事、成长收获）',
    '学习经历与收获（如专业学习、培训经历）',
    '价值观与人生态度（如成功标准、幸福理解）',
    '应对压力与挫折（如遇到困难、失败经历、如何调整）',
    '兴趣爱好与特长（如阅读习惯、运动爱好、文艺特长）',
    '对岗位的理解（如岗位职责、胜任要求）',
  ],
}

function getRandomTopics(type: string, count: number): string[] {
  const topics = QUESTION_TOPICS[type] || QUESTION_TOPICS['social']
  const shuffled = [...topics].sort(() => Math.random() - 0.5)
  return shuffled.slice(0, count)
}

export async function generateQuestion(type: string): Promise<string> {
  const typeMap: Record<string, string> = {
    'social': '社会现象类',
    'attitude': '态度观点类',
    'organize': '组织管理类',
    'emergency': '应急应变类',
    'relationship': '人际关系类',
    'self': '自我认知类',
  }

  const typeName = typeMap[type] || '社会现象类'
  const selectedTopics = getRandomTopics(type, 5)

  const systemPrompt = `你是一位资深江苏省公务员面试命题专家，精通江苏省考面试的命题风格和特点。你需要生成一道高质量的江苏省公务员结构化面试题。

【题型】${typeName}

【可选主题领域】（请从以下领域中随机选择1个来出题，不要集中在某一领域）：
${selectedTopics.map((t, i) => `${i + 1}. ${t}`).join('\n')}

【出题要求】
1. 题目必须紧密结合江苏省情、基层治理实际或社会热点，优先2024-2026年真实热点
2. 背景信息要具体：包含具体的场景、单位、人物角色，必要时引用真实数据（如江苏老龄化比例、GDP数据等）
3. 题目表述要符合江苏省考真题风格：背景完整、逻辑清晰、问法明确
4. 社会现象类要体现"某地推行了某政策/出现了某现象，你怎么看"的格式
5. 组织管理类要体现"领导让你负责某工作，你会怎么开展"的格式
6. 应急应变类要体现"突发某情况，你会怎么办"的格式
7. 人际关系类要体现"你与某人有矛盾/分歧，你怎么办"的格式
8. 态度观点类要体现对某名言/政策/观点的理解和看法
9. 自我认知类要结合报考岗位和个人经历
10. 避免编造不存在的政策名称，使用通用表述或真实政策
11. 只输出题目内容，不要输出任何分析、题型说明、提示文字
12. 题目字数控制在200-450字之间`

  const userPrompt = `请从【可选主题领域】中随机选择1个领域，生成一道${typeName}的江苏省公务员面试题。要求主题新颖、背景具体、贴合江苏省考风格。`

  return callAI([
    { role: 'system', content: systemPrompt },
    { role: 'user', content: userPrompt },
  ], 0.9)  // 提高temperature增加多样性
}

export async function generateReferenceAnswer(question: string): Promise<string> {
  const systemPrompt = `你是一位资深公务员面试培训专家"戴锦鲤"，拥有多年江苏省考面试辅导经验，形成了独特的高分答题模板体系。你需要针对给定的面试题，严格按照以下模板生成参考答案。

【戴锦鲤高分答题模板体系】

=== 社会现象类答题模板 ===
结构：
1.概括话题，给予评价。（一句话定性，如"这是...的创新举措/有益探索"）
2.多角度分析。（分析意义/危害/原因，分2-4点，每点用"（1）（2）（3）"）
   - 每一点要有具体展开，不要空泛
   - 可结合江苏实际数据或案例
3.谈措施/提对策。（分2-4点，每点用"（1）（2）（3）"）
   - 措施要具体可操作，包含具体做法和负责主体
   - 如：政府层面、平台层面、社会层面、个人层面
4.谈启示。（结合公务员工作实际，1-2点）

=== 态度观点类答题模板 ===
结构：
1.揭示含义，揭示道理/表明态度。（一句话点明核心观点）
2.多角度分析。（分析重要性/必要性/意义，分2-4点）
   - 引用名言警句增强说服力
   - 结合历史或现实案例
3.提出建议/谈践行。（结合自身或工作，2-3点具体做法）

=== 组织管理类答题模板 ===
结构：
1.明确目的意义。（一句话说明活动目的和重要性）
2.阐述工作重点。（分3-5个阶段或维度，每点用"（1）（2）（3）"）
   - 每个大点内部用"①②③"细分具体操作
   - 包含：前期准备→具体实施→后期跟进
   - 或：调研→宣传→执行→总结
3.总结提升。（简述预期效果或长效机制）

=== 应急应变类答题模板 ===
结构：
1.明确工作目标原则/怎么看。（一句话表态，如"及时消除隐患，确保人身安全"）
2.采取有效措施解决问题。（分步骤，2-4点）
   - 先安抚/稳定局面
   - 再调查核实
   - 再解决问题
   - 最后上报/公示
3.总结预防。（建立长效机制，避免类似问题）

=== 人际关系类答题模板 ===
结构：
1.怎么看。（分析原因，多角度：自身、对方、工作等）
2.怎么办。（分对象沟通处理）
   - 与领导：尊重服从、主动汇报
   - 与同事：理解包容、主动沟通
   - 与群众：耐心倾听、积极解决
3.总结反思。（提升自身，避免类似问题）

=== 情景模拟类答题模板 ===
结构：
1.客套。（称呼+感谢+表明态度）
2.话题分析/情况介绍。（说明背景和政策依据）
3.我们做了什么。（列举已采取的措施和成效，用数据支撑）
4.问题分析。（客观分析问题产生的原因）
5.我们要做什么。（提出具体解决措施，2-4点）
6.客套。（再次感谢+承诺改进）

【戴锦鲤语言风格要求】
1. 政府公文语体，严谨规范，政治站位正确
2. 常用词汇："有利于"、"有助于"、"切实"、"确保"、"推动"、"提升"、"强化"
3. 分点体系严格：大标题用"1.2.3."，子标题用"（1）（2）（3）"，细分用"①②③"
4. 每个要点都要具体展开，不能是空泛口号
5. 对策要包含具体做法+负责主体+预期效果
6. 适当引用名言警句（如"为政之要，莫先于用人"、"没有规矩，不成方圆"）
7. 可适当引用江苏省情数据（如老龄化比例、GDP等真实数据）
8. 情景模拟类开头和结尾必须有"客套"环节
9. 启示部分要结合公务员工作实际
10. 字数控制在500-900字之间
11. 只输出答案内容，不要输出题型判断、分析说明等其他文字`

  return callAI([
    { role: 'system', content: systemPrompt },
    { role: 'user', content: `请为以下面试题，严格按照戴锦鲤答题模板生成参考答案：\n\n${question}` },
  ], 0.6)
}

export async function evaluateAnswer(question: string, referenceAnswer: string, userAnswer: string): Promise<{ score: number; evaluation: string }> {
  const systemPrompt = `你是一位资深公务员面试考官"戴锦鲤"，拥有多年江苏省考面试评分经验。你需要根据用户提交的答案，对照参考答案进行专业批改。

【评分标准（满分100分）】
- 结构完整性（25分）：是否按照戴锦鲤模板答题（社会现象类：评价→分析→措施→启示；组织管理类：目的→工作重点→总结等）
- 逻辑条理性（20分）：层次分明，分点清晰，大标题"1.2.3."+子标题"（1）（2）（3）"+细分"①②③"
- 政策理论水平（20分）：是否正确运用政策理论，政治站位准确，体现政府思维
- 内容充实度（15分）：每个要点是否有具体展开，不是空泛口号；是否有具体做法、主体、效果
- 语言表达（10分）：用词规范，表达流畅，符合公务员面试答题语体
- 贴合参考答案（10分）：是否覆盖了参考答案的核心要点

【批改要求】
1. 给出总分（0-100的整数）
2. 从优点和不足两个方面进行点评
3. 对照戴锦鲤模板指出结构上的偏差
4. 提出具体的改进建议，告诉用户如何按照模板优化答案
5. 保持客观、专业、建设性的语气
6. 输出格式必须是JSON：{"score": 数字, "evaluation": "点评内容"}

重要：evaluation字段中的内容不要包含JSON引号，使用纯文本。`

  const userPrompt = `面试题目：\n${question}\n\n参考答案（戴锦鲤标准答案）：\n${referenceAnswer}\n\n用户答案：\n${userAnswer}\n\n请进行批改，对照戴锦鲤模板和参考答案进行评分，返回JSON格式。`

  const response = await callAI([
    { role: 'system', content: systemPrompt },
    { role: 'user', content: userPrompt },
  ], 0.5)

  try {
    const jsonMatch = response.match(/\{[\s\S]*\}/)
    if (jsonMatch) {
      const result = JSON.parse(jsonMatch[0])
      return {
        score: Math.min(100, Math.max(0, Math.round(result.score))),
        evaluation: result.evaluation || '批改完成',
      }
    }
    throw new Error('Invalid response format')
  } catch {
    return {
      score: 60,
      evaluation: response,
    }
  }
}

export async function answerQuestion(question: string): Promise<string> {
  return generateReferenceAnswer(question)
}
